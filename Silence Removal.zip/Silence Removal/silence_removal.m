close all; clear all;

% Read sound file
[data, fs] = audioread('Believer.wav');

data = data(1:end,1)/max(data(1:end,1));

% do framing
f_d = 0.025;
f_size = round(f_d * fs);
n = length(data);
n_f = floor(n/f_size);  %no. of frames
temp = 0;
for i = 1 : n_f
    
   frames(i,:) = data(temp + 1 : temp + f_size);
   temp = temp + f_size;
end

% silence removal based on max amplitude
m_amp = abs(max(frames,[],2)); % find maximum of each frame
id = find(m_amp > 0.03); % finding ID of frames with max amp > 0.03
fr_ws = frames(id,:); % frames without silence

% reconstruct signal
data_r = reshape(fr_ws',1,[]);
subplot(2,2,1);
plot(data_r); title('speech without silence');
subplot(2,2,2);
plot(data,'r');
legend('After Silence Removal','Original Signal');